
package hellogui;

import java.awt.BorderLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.DefaultListModel;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class Gui extends JFrame {
    
//declaring viaraible
    JButton addButton;
    JButton removeButton;
    JLabel label;
    JList<ToDo> list;
    JTextField text;
    DefaultListModel<ToDo> listModel;

    public Gui() {
        super("My To Do List:");
        setBounds(533, 284, 300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        //instantiate(eerste keer n variable set)
        label = new JLabel("To do:");
        addButton = new JButton("Add");
        removeButton = new JButton("Remove");

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ToDo toDoEnter = new ToDo(text.getText());
                listModel.addElement(toDoEnter);
                text.setText("");
            }
        }
        );

        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                List<ToDo> selected = list.getSelectedValuesList();

                for (int i = 0; i < selected.size(); i++) {

                    ToDo remove = selected.get(i);
                    listModel.removeElement(remove);
                }

            }
        });

        text = new JTextField(50);
        text.setSize(100, 100);
//        text.setColumns();

        listModel = new DefaultListModel();
        listModel.addElement(new ToDo("Milk"));
        listModel.addElement(new ToDo("Sugar"));
        listModel.addElement(new ToDo("Eggs"));
        listModel.addElement(new ToDo("Cereal"));

        list = new JList();
        list.setModel(listModel);
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        list.setLayoutOrientation(JList.VERTICAL);

        
        JPanel panel = new JPanel();
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        panel.setLayout(new BorderLayout());
        
        panel.setLayout(new BorderLayout());
        panel.add(label, BorderLayout.NORTH);
        panel.add(list, BorderLayout.CENTER);
        bottomPanel.add(addButton, BorderLayout.WEST);
        bottomPanel.add(removeButton, BorderLayout.EAST);
        bottomPanel.add(text, BorderLayout.CENTER);
        
        panel.add(bottomPanel,BorderLayout.SOUTH);
        add(panel);
        setVisible(true);

    }

}
